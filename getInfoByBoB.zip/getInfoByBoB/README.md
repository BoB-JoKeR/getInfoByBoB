# get all information By BoB
get all information for everything 
